Warna <br/>
   	<?php
    	echo form_dropdown("id_warna_kain",$option_warna,'',"id='id_warna_kain'");
    ?>
